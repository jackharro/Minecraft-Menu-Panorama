﻿using System;

namespace Minecraft
{
    public class NoiseGenerator
    {
    }
}
